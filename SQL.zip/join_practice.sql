select top 2 * from empl
select top 2 * from Company
select top 2 * from dept
select top 2 * from state
select top 2 * from Employee
select top 2 * from city

select emp_name,emp_email,emp_salary,d_name
from empl e
join dept d on e.dept_id = d.d_id

select employee_name,company_name,city_name,state_name from Employee e
join company c on e.employee_company=c.company_id
join city ci on e.employee_city=ci.city_id
join state s on s.state_id=ci.state

select distinct company_name from Company

select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],cr.name as [Sales Territory Country], cr.name as [sales territory region],
sum(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
	inner join person.countryregion as cr on st.CountryRegionCode=cr.CountryRegionCode
	group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name
	order by [Calendar Year]

select * from dept
insert into dept(d_name) values ('sales')

insert into dept(d_id,d_name) values (?,Sales+cast(? as varchar(10)))

alter table test add name varchar(10)
select * from  

update test 
set name='shubham'

