select *from faltu
select * from empl

select * from empl1

delete empl1 where emp_id=11

declare @a int = 12

while @a<=161
begin
	delete empl1 where emp_id=@a
	set @a+=1
end

truncate table empl1 


declare @maxid int
set @maxid = (select max(emp_id) from empl1)
print @maxid

select * from [Sales].[SalesOrderDetail]
select ROW_NUMBER() over(order by salesorderid) salesorderid from [Sales].[SalesOrderDetail]


select * from HumanResources.Employee