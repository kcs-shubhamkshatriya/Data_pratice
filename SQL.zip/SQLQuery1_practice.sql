create table empl(
emp_id int primary key identity(1,1),
emp_name varchar(100),
emp_email varchar(100),
emp_gender char(1)
)

select * from empl

insert into empl(emp_name,emp_email,emp_gender) values ('shubham','shubham@gmail.com','M')

drop table empl


create table empl(
emp_id int primary key identity(1,1),
emp_name varchar(100),
emp_email varchar(100),
emp_gender char(1) 
)

insert into empl(emp_name,emp_email,emp_gender) values('Yash','Yash@gmail.com','M'),('Malay','malay@gmail.com','M')

select * from [Shubham.Kshatriya].dbo.empl

alter table empl alter column	emp_gender varchar(100) 


create database demo

select * from sys.databases where database_id = 22

select * from sys.tables

alter table empl add phone_no numeric(10)

update empl set phone_no = 8200205157 where emp_id=1 

update empl set phone_no = 8200205112 where emp_id=2 
update empl set phone_no = 8200205113 where emp_id=3 

delete from empl where emp_id=4

alter table empl add emp_salary numeric(10) check(emp_salary > 6000)

select * from empl

update empl set emp_salary = 20000 where emp_id = 3

select * into empl_bkp from empl 
select * from empl_bkp

select coalesce('a','b','c','d','e')
select coalesce('','b','c','d','e')


declare @name varchar(101) = 'Nitish'
print @name

declare @i int = 10
declare @j int = 1
while @j<=10
begin
	print cast(@i as varchar)+'*'+ cast(@j as varchar) + '=' + cast(@i*@j as varchar)
	set @j +=1
end 

select max(emp_salary) from empl where emp_salary<(select emp_id,emp_name max(emp_salary) from empl)


print (ceiling(rand()*20))

alter table empl add emp_city varchar(50)

update empl 
set emp_city = 'Surat'
where emp_id = 2

select * from empl

select emp_name,emp_gender,isnull(emp_city,'abc') emp_city from empl

update empl
set emp_city = 'abc'
where emp_city is null


select coalesce(null,'b')
select *,coalesce(emp_city,'abc') from empl

select top 2 * from empl
select * from empl

alter table empl
add emp_dob date

update empl
set emp_dob = '1999/02/15'
where emp_id = 3

select *,day(emp_dob) year from empl
select *,month(emp_dob) year from empl

alter table empl
add emp_dob datetime

	select * from empl order by emp_city asc
select ascii('A')

select *,
case 
when emp_salary = 20000
then 'low'
else 'high' 
end Scale
from empl

select emp_name,max(emp_salary) maxsalry from empl group by emp_name


declare @sal int
--select @sal = max(e_salary) from emp
set @sal = (select max(emp_salary) from empl)
select * from empl where emp_salary = @sal


select * from empl

select * from empl where emp_salary = (select max(emp_salary) from empl where emp_gender= 'F')


select * into emplbck from empl


select * from emplbck

delete from emplbck where emp_id =3

create table loop_tbl(
	id int primary key identity,
	name varchar(50),
	description varchar(50)

)

select * from loop_tbl
truncate table loop_tbl
insert into loop_tbl values ('shubham','shubham@gmail.com')


declare @i int = 1
while @i<=10000
begin
	insert into loop_tbl values ('shubham'+cast(@i as varchar(200)),'shubham'+cast(@i as varchar(20))+'@gmail.com')
	set @i+=1
end

