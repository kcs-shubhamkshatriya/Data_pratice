select * from empl order by emp_salary desc
insert into empl values('hello3','hello3@gmail.com','F',9857545290,38000,'Ahmedabad','1995/04/28')



-- 1st Task 
select * from empl where emp_salary in (
	select emp_salary from empl group by emp_salary having count(*) >1
)

--2nd Task

select top 1 emp_salary from (select top 5 * from empl order by emp_salary desc) as a group by emp_salary

SELECT min(emp_salary) FROM (SELECT TOP 6 emp_salary FROM empl ORDER BY emp_salary DESC) as TopFive


create table dept (
d_id int primary key identity,
d_name varchar(50)
 )
 insert into dept values ('IT'),('SUPPORT'),('HR'),('MANAGEMENT')

 select * from dept
 select * from empl

 alter table empl add constraint d_id foreign key references empl(emp_id)
alter table empl 
add d_id int 

create table dept (
d_id int primary key identity,
d_name varchar(50)
 )

 drop table empl

 create table empl(
emp_id int primary key identity(1,1),
emp_name varchar(100),
emp_email varchar(100),
emp_gender char(1),
emp_salary numeric(10),
dept_id int foreign key references dept(d_id)
)


insert into empl values('shubham5','shubham5@gmail.com','M',35000,2)
alter table empl 
add emp_salary numeric(10)


alter table empl drop column where object_id = 

update empl 
set emp_salary=32000
where emp_id = 5

 insert into dept values ('IT'),('SUPPORT'),('HR'),('MANAGEMENT')

 select * from empl

 
-- 3rd task
select * from empl where dept_id=2
select * from empl where dept_id<>2 

select * from empl where dept_id = (select dept_id from empl where emp_id=6)

--4th task
declare @avg int
set @avg = (select avg(emp_salary) from empl where dept_id=2)
print @avg
select * from empl  where emp_salary>@avg and dept_id=2


--5th task
declare @avg1 int
set @avg1 = (select avg(emp_salary) from empl where dept_id=2)
print @avg1
select * from empl where emp_salary>@avg1 


--6th task
declare @sal int
set @sal = (select emp_salary from empl where emp_id=3)
print @sal
select * from (select * from empl where dept_id = (select dept_id from empl where emp_id=1)) as d where emp_salary > @sal

--7th task
select avg(emp_salary) from  empl as e join dept as d on (e.emp_id=d.d_id) group by d.d_name
 select * from empl


 